local ForceCompostable = Class(function(self, inst)
    self.inst = inst
    self.green = false
    self.brown = false
end)

return ForceCompostable