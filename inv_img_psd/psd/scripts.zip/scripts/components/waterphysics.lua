local WaterPhysics = Class(function(self, inst)
    self.inst = inst

    self.restitution = 1
end)

return WaterPhysics
