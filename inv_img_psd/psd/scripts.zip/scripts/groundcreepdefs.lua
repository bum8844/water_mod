local TileManager = require("tilemanager")

TileManager.AddGroundCreep(
    GROUND_CREEP_IDS.WEBCREEP,
    {
        name = "web",
        noise_texture = "web_noise",
    }
)