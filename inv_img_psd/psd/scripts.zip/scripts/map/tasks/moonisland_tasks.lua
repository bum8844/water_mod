
require "map/tasks/dst_tasks_forestworld" -- all tasks from here were moved into dst_tasks_forestworld
