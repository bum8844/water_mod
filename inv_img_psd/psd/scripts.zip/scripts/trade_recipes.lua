TRADE_RECIPES =
{
	classy_upgrade =
	{
		name = "9_CLASSY_UPGRADE",
		inputs =
		{
			number = 9,
			rarity = "Classy",
		},
	},
	common_upgrade =
	{
		name = "9_COMMON_UPGRADE",
		inputs =
		{
			number = 9,
			rarity = "Common",
		},
	},
	spiffy_upgrade =
	{
		name = "9_SPIFFY_UPGRADE",
		inputs =
		{
			number = 9,
			rarity = "Spiffy",
		},
	},
}
